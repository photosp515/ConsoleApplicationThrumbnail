﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ContextProxyClassLibrary
{
    public class Class1
    {
        //ieframe to msdb flex grid from text context



    }
}
