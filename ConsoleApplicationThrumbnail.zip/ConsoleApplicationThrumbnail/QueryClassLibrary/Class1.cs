﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryClassLibrary
{
    public class Class1
    {
    }
}
