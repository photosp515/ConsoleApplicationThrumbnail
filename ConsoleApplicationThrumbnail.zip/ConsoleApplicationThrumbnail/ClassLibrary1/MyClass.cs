﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibrary1
{
    class MyClass
    {
        //XQuery
        //msrodb
        //.net
        //ms.runtime
    }
}
