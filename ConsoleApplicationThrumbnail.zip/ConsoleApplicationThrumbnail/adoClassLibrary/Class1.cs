﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity.Design;
using System.Data.Entity.Design.PluralizationServices;
using System.Drawing;
namespace adoClassLibrary
{
    public class Class1
    {
        public Class1()
        {
            System.Drawing.TextureBrush draw = new System.Drawing.TextureBrush();
            draw.Image = new Image();
        }
    }
}
